# Tests proper handling of lextab and parsetab files in package structures

# Here for testing purposes
import sys
if '..' not in sys.path:  
    sys.path.insert(0, '..')

from .parsing.calcparse import parser

